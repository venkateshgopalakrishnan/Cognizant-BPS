
/*var gData;*/
/*$(document).ready(*/
//		function() {

			var url = "http://localhost:3100/customers/list/";

			$.ajax({
				type : "GET",
				url : url,
				dataType : "json",
				async : false,
				success : function(response) {
					/*gData=response;*/
                     console.log(response);
					var trHTML = '';

//					for(i=0;i<gData.length;i++){
			$.each(response, function(i, item) {
						trHTML += '<tr><td>' + item.customerId + '</td><td>'
								+ item.customerName + '</td><td>'+item.customerContactNumber+'</td></tr>';
						
//					}
					});

					$('#records-table').append(trHTML);

				}

			/*});*/
		});
